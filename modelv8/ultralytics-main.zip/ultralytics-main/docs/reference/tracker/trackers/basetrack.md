---
description: 'TrackState: A comprehensive guide to Ultralytics tracker''s BaseTrack for monitoring model performance. Improve your tracking capabilities now!'
---

# TrackState
---
:::ultralytics.tracker.trackers.basetrack.TrackState
<br><br>

# BaseTrack
---
:::ultralytics.tracker.trackers.basetrack.BaseTrack
<br><br>
